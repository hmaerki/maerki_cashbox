﻿using Raptorious.SharpMt940Lib;
using Raptorious.SharpMt940Lib.Mt940Format;
using System;
using System.Globalization;

namespace MT940Test
{
  class Program
  {
    static void Main(string[] args)
    {
      // string filename = @"D:\cashbox\trunk\hikizi\2016\journal_MT940.sta";
      string filename = @"D:\cashbox\branches\cashboxNet\bosshard\Raiffeisen Andre\SWIFT Jahresauszug mit Details - Konto_20170902183453.mt940";
      // var result = Mt940Parser.Parse(new AbnAmro(), filename, CultureInfo.InvariantCulture);

      // FullParseTests.cs
      /*
      var header = new Separator("ABNANL2A", "940", "ABNANL2A");
      var footer = new Separator("-");
      var result = Mt940Parser.Parse(new GenericFormat(header, footer), filename, CultureInfo.InvariantCulture);
  */

      // FullParseTests.cs
      /*
      var header = new Separator("0000 01INGBNL2AXXXX00001", "0000 01INGBNL2AXXXX00001", "940 00");
      var footer = new Separator("XXX");
      var result = Mt940Parser.Parse(new GenericFormat(header, footer), filename, CultureInfo.InvariantCulture);
      */
      Parameters mt940Parameters = new Parameters();
      mt940Parameters.AddCodeFor(TransactionDetail.Description, "~NS");
      // mt940Parameters.AddCodeFor(MT940TrDetail.Description, "~22");
      var header = new Separator("");
      var footer = new Separator("");
      var result = Mt940Parser.Parse(new GenericFormat(header, footer), filename, CultureInfo.InvariantCulture, mt940Parameters);

      Console.WriteLine($"Count: {result.Count}");
      foreach (CustomerStatementMessage statement in result)
      {
        Console.WriteLine($"Description OpeningBalance: {statement.Description} {statement.OpeningBalance}");
        int i = 0;
        foreach (Transaction transaction in statement.Transactions)
        {
          if (i++ > 5)
          {
            break;
          }
          Console.WriteLine($"{transaction.ValueDate} {transaction.DebitCredit} {transaction.Amount} '{transaction.Description}'");
        }
      }
      // var result = Mt940Parser.Parse(new AbnAmro(), filename, CultureInfo.InvariantCulture);
      //  var result = Mt940Parser.ParseData(new AbnAmro(), data, CultureInfo.InvariantCulture);
    }
  }
}
