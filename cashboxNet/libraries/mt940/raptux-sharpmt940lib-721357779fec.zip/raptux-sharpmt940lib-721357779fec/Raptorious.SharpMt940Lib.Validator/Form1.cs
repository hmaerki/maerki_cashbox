﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Raptorious.SharpMt940Lib.Validator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            FileDialog open = new OpenFileDialog();
            if(open.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtFile.Text = open.FileName;
            }
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            var fileName = txtFile.Text;
            if(System.IO.File.Exists(fileName))
            {
                var header = new Raptorious.SharpMt940Lib.Mt940Format.Separator("STARTUMSE");
                var trailer = new Raptorious.SharpMt940Lib.Mt940Format.Separator("-");
                var genericFomat = new Raptorious.SharpMt940Lib.Mt940Format.GenericFormat(header, trailer);

                var ci = CultureInfo.GetCultureInfo("fr-FR");
                var parsed = SharpMt940Lib.Mt940Parser.Parse(genericFomat, fileName, ci);
                gridResult.DataSource = parsed;
            }
        }

        private void gridResult_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            var dataSource = ((ICollection<CustomerStatementMessage>)((DataGridView)sender).DataSource);
            gridTransactions.DataSource = dataSource.ElementAt(e.RowIndex).Transactions;
        }
    }
}
